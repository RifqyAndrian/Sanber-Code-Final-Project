 AutomationTesting-KasirAja

Step Install Cypress
1. Create new project or new folder
2. Initialize a new Node.js project -> npm init -y
3. Install Cypress -> npm install cypress --save-dev
4. Verify the Installation -> npx cypress open



